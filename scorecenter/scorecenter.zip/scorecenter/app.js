//Hamid Mansoor
//Comp 20
//Assignment 5

var express = require('express')
  , routes = require('./routes')
  , user = require('./routes/user')
  , http = require('http')
  , path = require('path');

var app = express();

app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'jade');
app.use(express.favicon());
app.use(express.logger('dev'));
app.use(express.bodyParser());
app.use(express.methodOverride());
app.use(app.router);
app.use(require('stylus').middleware(__dirname + '/public'));
app.use(express.static(path.join(__dirname, 'public')));

var mongoUri = 'mongodb://hmanso02:GeetoGola1992@ds033887.mongolab.com:33887/a5'

var mongo = require('mongodb');
var db = mongo.Db.connect(mongoUri, function (error, databaseConnection) {
  db = databaseConnection;
});

//Allowing Cross origin sharing for appropriate features
app.all('/submit.json', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
});

app.all('/highscores.json', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
});

app.all('/searchresults', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });
//Displaying all the scores and games on the main page
app.get('/', function(req, response){
  allgames = [];
  db.collection('highscores', function(err, collection) {
    collection.find().toArray(function(err, items) {
      for(i = 0; i < items.length; i++){
        var game = {  "game_title":items[i].game_title, 
                      "username":items[i].username, 
                      "score": items[i].score,
                      "created_at":items[i].created_at,
                      "_id":items[i]._id};
        allgames.push(game); 
      }  
      var now = new Date();
      response.send(allgames ); 
    });
  });
});
//Using a form for getting the search query
app.get('/usersearch', function(req, response){
  response.set('Content-Type', 'text/html');
  response.send(' <FORM action="/searchresults" method="post"> <P> Username: <INPUT type="text" id="input" name="username"><BR>  <INPUT type="submit" id="submit" value="Submit"> <INPUT type="reset"> </P> </FORM>');
});
//Displaying the results from the search
app.post('/searchresults', function(request, response) {
  var username = request.body.username;
  db.collection('highscores', function(err, collection) {
    collection.find({'username': username}, function(err, items) {
      items.toArray(function(err, game){
        for(i = 0; i < game.length; i++){
          var time = game[i].created_at;
          game[i].created_at = time;
        }
        response.send(game); 
      });
    });
  }); 
});

if ('development' == app.get('env')) {
  app.use(express.errorHandler());
}
//Making the post api for users to submit information
app.post('/submit.json', function (request, response) {
  var title = request.body.game_title;
  var username = request.body.username;
  var score = request.body.score;
  var id = request.body._id;
  var now = new Date();
  var game = { "game_title": title, 
               "username": username, 
               "score": score,
               "created_at":now.toGMTString() 
               /*"_id":id*/};
  db.collection('highscores', function(err, collection) {
    collection.insert(game, {safe:true}, function(err, result) {
      if (err) {
        response.send({'error':'An error has occurred'});
      } else {
      }
    });
  });
});
//Making the highscores.json post
app.get('/highscores.json', function(request, response) {
  response.set('Content-Type', 'text/html');
  var gametitle = request.query.game_title;
  db.collection('highscores', function(err, collection) {
    playersdata = [];
    scores = [];
    sorteddata = [];
    collection.find({'game_title': gametitle}, function(err, items) {
      items.toArray(function(err, game){
        for(i = 0; i < game.length; i++){
          var player = {"game_title":game[i].game_title, 
                        "username":game[i].username,
                        "score":game[i].score,
                        "created_at":game[i].created_at,
                        "_id":game[i]._id,
                        "isadded":0};
          playersdata.push(player);
          scores.push(game[i].score);  
        }
      scores.sort(function(a,b){return b-a});
      var counter = 0;
      for (c = 0; c < scores.length; c++){
        for (d = 0; d < playersdata.length; d++){
          if (scores[c] == playersdata[d].score && counter < 10 
              && playersdata[d].isadded == 0 ){
          counter++;
          var sortedplayer = 
                     {"game_title":playersdata[d].game_title, 
                      "username":playersdata[d].username,
                      "score":playersdata[d].score,
                      "created_at":playersdata[d].created_at,
                      "_id":playersdata[d]._id};
            playersdata[d].isadded = 1;
            sorteddata.push(sortedplayer);
          }
        }
      }
      response.send(sorteddata); 
    });
  });
}); 
});

app.get('/', routes.index);
app.get('/users', user.list);

http.createServer(app).listen(app.get('port'), function(){
  console.log('Express server listening on port ' + app.get('port'));
});
